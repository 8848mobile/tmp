<!DOCTYPE html>
<html>
<head>
<meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>该页面不存在</title>
    <link rel="shortcut icon" href="favicon.ico">
<link type="text/css" rel='stylesheet' href="css/404life.css">
<script type="text/javascript" src='js/404life.js'></script>
  <script>
  window.console = window.console || function(t) {};
</script>
  <script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }
</script>
</head>

<body translate="no" >
  <div class='terminal'>
  <h1 id='title'>404,真不好意思，你的电脑被入侵了！</h1>
  <div class='text' id='text_1'></div>
  <div class='text' id='text_2'></div>
  <div class='cursor'>_</div>
  <script src='js/jquery.min.js'></script>
<br/><br/><br/><p style="text-align: center;"><a href="../index.php">返回首页</a></p>
</body>
</html>