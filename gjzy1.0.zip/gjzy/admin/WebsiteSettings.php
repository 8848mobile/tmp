<?php
$scok = '0'; //网站开关  0为开  1为关
$scoks = '网站维护中,暂时关闭站点';//网站关闭说明
//------------------------------------------------------------↑网站维护开关↑-----------------------------------------------------------------

//-------------------------------------------------------------网站基本设置↓------------------------------------------------------------------
$owner="正经人";
$array = [
      'siteurl' =>'index.php', //主页网站链接

	  
      'title' =>$owner.'的主页 | 不要停止前进的脚步！',//网站title名字
	  
	  'keywords'=>'',//为搜索引擎定义关键词
	  
	  'description'=>$owner.' | 不要停止前进的脚步！',//为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容
	  
	  'author'=>$owner,//定义网页作者
	  
	  'sitedate'=>'2024-07-26',//建站日期
	  
	  'favicon'=>'https://www.shufazi.cn/sucai/zb_users/upload/2018/20180409174113214.jpg',//网站图标，可输入网址
	  
	  'logo'=>'https://img2.baidu.com/it/u=1298760756,3774938409&fm=253&fmt=auto&app=138&f=JPEG?w=300&h=300',//网站logo，可输入网址
	  
	  'ncimg'=>'https://pic.52112.com/180610/JPG-180610_514/wdNWY9mUTZ_small.jpg',//站长昵称img
      
      'qq' =>'不告诉你',//你的qq号 用于显示头像
	  
	  'mail'=>'不告诉你@qq.com',//邮箱
	  
	  'mp1'=>'+86 不告诉你',//手机号1
	  
	  'mp2'=>'+86 不告诉你 ',//手机号2
	  
	  'wxid'=>'不告诉你',//微信号
	  
	  'loc'=>'China',//地址
      
      'nc'=>$owner,//你的昵称 用于首页显示和网站版权
	  
	  'bkmc'=>$owner.'的主页',//博客名称
	  
      'Introduction'=>'不要停止前进的脚步！',//介绍或者签名
	  
	  'carousel'=>' 欢迎来到 <b>'.$owner.'的主页</b> <img src="assets/images/star1.svg" alt="Star"> 欢迎来到 <b>'.$owner.'的主页</b> <img src="assets/images/star1.svg" alt="Star"> 欢迎来到 <b>'.$owner.'的主页</b> <img src="assets/images/star1.svg" alt="Star"> 欢迎来到 <b>'.$owner.'的主页</b> <img src="assets/images/star1.svg" alt="Star"> 欢迎来到 <b>'.$owner.'的主页</b> <img src="assets/images/star1.svg" alt="Star">',//文字轮播内容
      
      'link'=>'./index.php',//菜单栏按钮 点击后跳转的网址
	  
	  'linkbutton'=>'进入主页',//菜单栏按钮 的文字
	  
	  'Copyright'=>'<p class="copyright">&copy; All rights reserved by <a href="./">hxl</a><br /><a href="https://beian.miit.gov.cn/" style="color:#FFFFFF">备案号：8867715</a></p>',//网站底部版权
	  
	  'count'=>'',//网站的统计代码
	  
	  'history1'=>'<p class="date">2024-5-12</p><p>人性难评！</p><p class="date">2024-05-13</p><p>哪怕是深爱之人 对我们的痛苦一无所知！</p><p class="date">2024-05-14</p><p>越来越变得孤独了，大概这就是我想要的生活罢了！</p><p class="date">2024-05-15</p><p>我所遇到的每个人都给我上了难忘的一节课！</p><p class="date">2024-05-15</p><p>成年人的世界都不容易</p>',//关于页面的历程1
	  
	  'history2'=>'<p class="date">2023-12-03</p><p>那一刻我看清了自己，不是你！</p><p class="date">2023-12-31</p><p>今年的最后一天，希望下一年更加努力</p><p class="date">2023-01-12</p><p>没有住处的感觉我终于体会到了！</p><p class="date">2023-01-27</p><p>跟家人见面，很开心！</p>',//关于页面的历程2
	  
  ];
  $siteurl = $array ['siteurl'];
  $title = $array ['title'];
  $keywords=$array ['keywords'];
  $description=$array ['description'];
  $author=$array ['author'];
  $sitedate=$array['sitedate'];
  $favicon=$array ['favicon'];
  $logo=$array ['logo'];
  $ncimg=$array ['ncimg'];
  $qq= $array ['qq'];
  $mail= $array ['mail'];
  $mp1= $array ['mp1'];
  $mp2= $array ['mp2'];
  $wxid= $array ['wxid'];
  $loc= $array ['loc'];
  $nc= $array ['nc'];
  $bkmc=$array ['bkmc'];
  $Introduction= $array ['Introduction'];
  $carousel=$array ['carousel'];
  $link=$array ['link'];
  $linkbutton=$array ['linkbutton'];
  $Copyright=$array ['Copyright'];
  $count=$array ['count'];
  $history1=$array ['history1'];
  $history2=$array ['history2'];
  
//--------------------------------------------------------------旗下网站设置区1------------------------------------------------------------------
//--------------------------------------------------------------每个区域最多放置两个，多了自己修改下面代码和sites.php里面的代码，在下面添加wzlb3，以此类推------------------------------------------------------------------
  $arrl = array(
    array(
       'wzbt' =>$owner.'的主页',//网站名字
       'wzjs' =>$owner.'的主页',//网站介绍
       'wzlink' =>'./HACKER731/index.php',//点击后的跳转链接
       'wzimg' =>'https://img2.baidu.com/it/u=3321272976,246499435&fm=253&fmt=auto&app=138&f=JPEG?w=580&h=330',//图标
    ),
      array(
          'wzbt' =>'敬请期待',//网站名字
          'wzjs' =>'敬请期待',//网站介绍
          'wzlink' =>'./HACKER731/index.php',//点击后的跳转链接
          'wzimg' =>'https://img2.baidu.com/it/u=3321272976,246499435&fm=253&fmt=auto&app=138&f=JPEG?w=580&h=330',//图标
      ),
    array(
       'wzbt' =>'敬请期待',//网站名字
       'wzjs' =>'敬请期待',//网站介绍
       'wzlink' =>'./HACKER731/index.php',//点击后的跳转链接
       'wzimg' =>'https://img2.baidu.com/it/u=3321272976,246499435&fm=253&fmt=auto&app=138&f=JPEG?w=580&h=330',//图标
    ),
    array(
       'wzbt' =>'敬请期待',//网站名字
       'wzjs' =>'敬请期待',//网站介绍
       'wzlink' =>'./HACKER731/index.php',//点击后的跳转链接
       'wzimg' =>'https://img2.baidu.com/it/u=3321272976,246499435&fm=253&fmt=auto&app=138&f=JPEG?w=580&h=330',//图标
    ),

    
);
$wzlbb = count($arrl);
?>