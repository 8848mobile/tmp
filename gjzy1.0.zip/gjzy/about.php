﻿<?php
include('./admin/WebsiteSettings.php');
if ($scok==1) {
    session_start();
    $_SESSION['count'] = 1;
    header("Location: 404.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="UTF-8">
    <title>About - <?php echo $title; ?></title>
    <!--为搜索引擎定义关键词-->
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->
    <meta name="description" content="<?php echo $description; ?>"> 
    <!--定义网页作者-->
    <meta name="author" content="<?php echo $author; ?>"> 
    <!--网站版权-->
    <meta name="copyright" content="<?php echo $nc; ?>">
    <!--指定IE和Chrome使用最新版本渲染当前页面-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <!--指导浏览器如何缓存某个响应以及缓存多长时间-->
    <!--no-cache:先发送请求,与服务器确认该资源是否被更改,如果未被更改,则使用缓存
    no-store:不允许缓存,每次都要去服务器上,下载完整的响应(安全措施)
    public:缓存所有响应,但并非必须,因为max-age也可以做到相同效果
    private:只为单个用户缓存,因此不允许任何中继进行缓存,(比如说CDN就不允许缓存private的响应)
    maxage:当前请求开始,该响应在多久内能被缓存和重用,而不去服务器重新请求,例:max-age=60表示响应可以再缓存和重用60秒
    -->
    <meta http-equiv="cache-control" content="no-cache">
    <!--禁止百度自动转码 用于禁止当前页面在移动端浏览时,被百度自动转码,虽然百度的本意是好的,但是转码效果很多时候却不尽人意-->
    <!--meta http-equiv="Cache-Control" content="no-siteapp" /-->
    <!-- 分享网页时显示的标题-QQ-->
    <meta itemprop="name" content="<?php echo $title; ?>" />
    <!-- 分享网页时显示的缩略图-QQ-->
    <meta itemprop="image" content="<?php echo $favicon; ?>" />
    <!--分享网页时时显示的内容-QQ-->
    <meta name="description" itemprop="description" content="<?php echo $title; ?>" />
    <!--设置自动适应电脑和手机屏幕-->
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no minimal-ui">
    <!--设置浏览器栏favicon图标-->
    <link rel="icon" href="<?php echo $favicon; ?>" type="image/x-icon"/>
    <!--定义搜索引擎爬虫的索引方式-->
    <!--index,follow:可以抓取本页，而且可以顺着本页继续索引别的链接
    noindex,follow:不许抓取本页，但是可以顺着本页抓取索引别的链接
    index,nofollow:可以抓取本页，但是不许顺着本页抓取索引别的链接
    noindex,nofollow:不许抓取本页，也不许顺着本页抓取索引别的链接
    -->
    <meta name="robots" content="index,follow">

    <!-- Fonts -->
    <link href="./assets/css/css2.css" rel="stylesheet">
    <!-- css -->
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/aos.css">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>

    <main class="main-aboutpage">

        <!-- Header -->
        <header class="header-area">
            <div class="container">
                <div class="gx-row d-flex align-items-center justify-content-between">
                    <a href="./" class="logo">
                        <img src="<?php echo $logo; ?>" alt="" width="156" height="36">
                    </a>

                    <nav class="navbar">
                        <ul class="menu">
                            <li><a href="./index.php">首页</a></li>
                            <li class="active"><a href="./about.php">关于</a></li>
                            <li><a href="./sites.php">网站</a></li>
                            <li><a href="./contact.php">关于</a></li>
                        </ul>
                        <a href="<?php echo $link; ?>" class="theme-btn"><?php echo $linkbutton; ?></a>
                    </nav>

                    <a href="<?php echo $link; ?>" class="theme-btn"><?php echo $linkbutton; ?></a>

                    <div class="show-menu">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        </header>

        <!-- About -->
        <section class="about-area">
            <div class="container">
                <div class="d-flex about-me-wrap align-items-start gap-24">
                    <div data-aos="zoom-in">
                        <div class="about-image-box shadow-box">
                            <img src="assets/images/bg1.png" alt="" class="bg-img">
                            <div class="image-inner">
                                <img src="<?php echo 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fc-ssl.duitang.com%2Fuploads%2Fitem%2F201909%2F22%2F20190922013327_buivq.thumb.1000_0.jpg&refer=http%3A%2F%2Fc-ssl.duitang.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1718369878&t=c63552dcf379751ec82ee9a7ab248fe2' ;?>" alt="">
                            </div>
                        </div>
                    </div>

                    <div class="about-details" data-aos="zoom-in">
                        <h1 class="section-heading" data-aos="fade-up"><img src="assets/images/star-2.png" alt="">神 秘 人 <img src="assets/images/star-2.png" alt=""></h1>
                        <div class="about-details-inner shadow-box">
                            <img src="assets/images/icon2.png" alt="">
							<h1><?php echo $nc;?></h1>
                            <p><?php echo $Introduction;?></p>
                        </div>

                    </div>
                </div>

                <div class="row mt-24">
                    <div class="col-md-6" data-aos="zoom-in">
                        <div class="about-edc-exp about-experience shadow-box">
                            <img src="assets/images/bg1.png" alt="" class="bg-img">
                            <h3>最近更新</h3>

                            <ul>
                                <li>
								<?php echo $history1; ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6" data-aos="zoom-in">
                        <div class="about-edc-exp about-education shadow-box">
                            <img src="assets/images/bg1.png" alt="" class="bg-img">
                            <h3>在过去的某一天....</h3>

                            <ul>
                                <li>
								<?php echo $history2; ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row mt-24">
                    <div class="col-md-12">
                        <div class="d-flex profile-contact-credentials-wrap gap-24">

                            <div data-aos="zoom-in">
                                <div class="about-profile-box info-box shadow-box h-full">
                                    <img src="./assets/images/bg1.png" alt="" class="bg-img">
                                    <div class="inner-profile-icons shadow-box">
                                        <a href="./HACKER731/index.php">
                                            <iconpark-icon name="cross-ring-two"></iconpark-icon>
                                        </a>
                                        <a href="./HACKER731/index.php">
                                            <iconpark-icon name="star-one"></iconpark-icon>
                                        </a>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div class="infos">
                                            <h4>关于我</h4>
                                            <h1>联系我</h1>
                                        </div>
    
                                        <a href="./contact.php" class="about-btn">
                                            <img src="./assets/images/icon.svg" alt="">
                                        </a>
    
                                    </div>
                                </div>
                            </div>

                            <div data-aos="zoom-in" class="flex-1">
                                <div class="about-contact-box info-box shadow-box">
                                    <a class="overlay-link" href="./contact.php"></a>
                                    <img src="assets/images/bg1.png" alt="BG" class="bg-img">
                                    <img src="assets/images/icon2.png" alt="Icon" class="star-icon">
                                    <h1>要 <br>努力 <span>生活.</span></h1>
                                    <a href="./contact.php" class="about-btn">
                                        <img src="assets/images/icon.svg" alt="Button">
                                    </a>
                                </div>
                            </div>

                            <div data-aos="zoom-in" class="h-full">
                                <div class="about-crenditials-box info-box shadow-box">
                                    <a class="overlay-link" href="./more.php"></a>
                                    <img src="https://img2.baidu.com/it/u=1255012477,2307841856&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=330" alt="" class="bg-img">
                                    <img src="<?php echo $ncimg; ?>" alt=""  width="256" height="156">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div class="infos">
                                            <h4>更多</h4>
                                            <h1>关于我</h1>
                                        </div>
    
                                        <a href="./more.php" class="about-btn">
                                            <img src="https://img.ytxfz.com/upload/2818646.jpg" alt="">
                                        </a>
    
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Footer -->
        <footer class="footer-area">
            <div class="container">
                <div class="footer-content text-center">
                    <a href="https://img2.baidu.com/it/u=1688705048,712138211&fm=253&fmt=auto&app=138&f=PNG?w=250&h=250" class="logo">
                        <img src="<?php echo $logo;?>" alt="" width="156" height="36">
                    </a>
                    <ul class="footer-menu">
                        <li><a href="./index.php">首页</a></li>
                        <li><a href="./about.php">关于</a></li>
                        <li><a href="./sites.php">网站</a></li>
                        <li><a href="./contact.php">联系</a></li>
                    </ul>
                    <?php echo $Copyright; ?>
                    </p>
                </div>
            </div>
        </footer>

    </main>
    

    <script src="assets/js/jquery-3.6.4.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/aos.js"></script>
    <script src="assets/js/main.js"></script>
	<script src="./assets/js/icons.js"></script>
    <script type="text/javascript">
//求情
    console.log("%c大侠手下留情,不要搞小站。", "color: #ff146d;font-size: 16px;font-weight: bold")
//申明
    console.log("\n %c 孤独 %c \n", "color: #fadfa3; background: #030307; padding:5px 0; font-size:12px;", "background: #fadfa3; padding:5px 0; font-size:12px;");
    </script>
<!--统计-->
<?php echo $count; ?>
</body>
</html>
