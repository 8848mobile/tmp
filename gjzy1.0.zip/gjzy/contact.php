﻿<?php
include('./admin/WebsiteSettings.php');
if ($scok==1) {
    session_start();
    $_SESSION['count'] = 1;
    header("Location: 404.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="UTF-8">
    <title>Contact - <?php echo $title; ?></title>
    <!--为搜索引擎定义关键词-->
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <!--为网页定义描述内容 用于告诉搜索引擎，你网站的主要内容-->
    <meta name="description" content="<?php echo $description; ?>"> 
    <!--定义网页作者-->
    <meta name="author" content="<?php echo $author; ?>"> 
    <!--网站版权-->
    <meta name="copyright" content="<?php echo $nc; ?>">
    <!--指定IE和Chrome使用最新版本渲染当前页面-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <!--指导浏览器如何缓存某个响应以及缓存多长时间-->
    <!--no-cache:先发送请求,与服务器确认该资源是否被更改,如果未被更改,则使用缓存
    no-store:不允许缓存,每次都要去服务器上,下载完整的响应(安全措施)
    public:缓存所有响应,但并非必须,因为max-age也可以做到相同效果
    private:只为单个用户缓存,因此不允许任何中继进行缓存,(比如说CDN就不允许缓存private的响应)
    maxage:当前请求开始,该响应在多久内能被缓存和重用,而不去服务器重新请求,例:max-age=60表示响应可以再缓存和重用60秒
    -->
    <meta http-equiv="cache-control" content="no-cache">
    <!--禁止百度自动转码 用于禁止当前页面在移动端浏览时,被百度自动转码,虽然百度的本意是好的,但是转码效果很多时候却不尽人意-->
    <!--meta http-equiv="Cache-Control" content="no-siteapp" /-->
    <!-- 分享网页时显示的标题-QQ-->
    <meta itemprop="name" content="<?php echo $title; ?>" />
    <!-- 分享网页时显示的缩略图-QQ-->
    <meta itemprop="image" content="<?php echo $favicon; ?>" />
    <!--分享网页时时显示的内容-QQ-->
    <meta name="description" itemprop="description" content="<?php echo $title; ?>" />
    <!--设置自动适应电脑和手机屏幕-->
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no minimal-ui">
    <!--设置浏览器栏favicon图标-->
    <link rel="icon" href="<?php echo $favicon; ?>" type="image/x-icon"/>
    <!--定义搜索引擎爬虫的索引方式-->
    <!--index,follow:可以抓取本页，而且可以顺着本页继续索引别的链接
    noindex,follow:不许抓取本页，但是可以顺着本页抓取索引别的链接
    index,nofollow:可以抓取本页，但是不许顺着本页抓取索引别的链接
    noindex,nofollow:不许抓取本页，也不许顺着本页抓取索引别的链接
    -->
    <meta name="robots" content="index,follow">
    <!-- Fonts -->
    <link href="./assets/css/css2.css" rel="stylesheet">
    <!-- css -->
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/aos.css">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>

    <main class="main-aboutpage">

        <!-- Header -->
        <header class="header-area">
            <div class="container">
                <div class="gx-row d-flex align-items-center justify-content-between">
                    <a href="./" class="logo">
                        <img src="<?php echo $logo; ?>" alt="" width="156" height="36">
                    </a>

                    <nav class="navbar">
                        <ul class="menu">
                            <li><a href="./index.php">首页</a></li>
                            <li><a href="./about.php">关于</a></li>
                            <li><a href="./sites.php">网站</a></li>
                            <li class="active"><a href="./contact.php">联系</a></li>
                        </ul>
                        <a href="<?php echo $link; ?>" class="theme-btn"><?php echo $linkbutton; ?></a>
                    </nav>

                    <a href="<?php echo $link; ?>" class="theme-btn"><?php echo $linkbutton; ?></a>

                    <div class="show-menu">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        </header>

        <!-- Contact -->
        <section class="contact-area">
            <div class="container">
                <div class="gx-row d-flex justify-content-between gap-24">
                    <div class="contact-infos">
                        <h3 data-aos="fade-up">联系作者</h3>
                        <ul class="contact-details">
                            <li class="d-flex align-items-center" data-aos="zoom-in">
                                <div class="icon-box shadow-box">
                                    <iconpark-icon name="mail"></iconpark-icon>
                                </div>
                                <div class="right">
                                    <span>邮箱联系</span>
                                    <h4><?php echo $qq; ?>@qq.com</h4>
                                    <h4><br /></h4>
                                </div>
                            </li>

                            <li class="d-flex align-items-center" data-aos="zoom-in">
                                <div class="icon-box shadow-box">
                                    <iconpark-icon name="phone-telephone"></iconpark-icon>
                                </div>
                                <div class="right">
                                    <span>Contact me</span>
                                    <h4><?php echo $mp1; ?></h4>
                                    <h4><br /></h4>
                                </div>
                            </li>

                            <li class="d-flex align-items-center" data-aos="zoom-in">
                                <div class="icon-box shadow-box">
                                    <iconpark-icon name="wechat"></iconpark-icon>
                                </div>
                                <div class="right">
                                    <span>微信联系</span>
                                    <h4><?php echo $wxid; ?></h4>
                                    <h4><br /></h4>
                                </div>
                            </li>

                            <li class="d-flex align-items-center" data-aos="zoom-in">
                                <div class="icon-box shadow-box">
                                    <iconpark-icon name="local"></iconpark-icon>
                                </div>
                                <div class="right">
                                    <span>地址</span>
                                    <h4><?php echo $loc; ?><br> <br></h4>
                                </div>
                            </li>
                        </ul>

                    </div>

                    <div data-aos="zoom-in" class="contact-form">
                        <div class="shadow-box">
                            <img src="./assets/images/bg1.png" alt="" class="bg-img">
                            <img src="./assets/images/icon3.png" alt="">
                            <h1>有什么问题<span>找我.</span></h1>
                            <form method="POST" action="mailer.php">
                                <div class="alert alert-success messenger-box-contact__msg" style="display: none" role="alert">
                                    你的邮件已发送！
                                </div>
                                <div class="input-group">
                                    <input type="text" name="full-name" id="full-name" placeholder="请输入您的名字 ">
                                </div>
                                <div class="input-group">
                                    <input type="email" name="email" id="email" placeholder="请输入您的邮箱 ">
                                </div>
                                <div class="input-group">
                                    <textarea name="message" id="message" placeholder="请问，有什么想对我说的吗？"></textarea>
                                </div>
                                <div class="input-group">
                                    <button class="theme-btn submit-btn" name="submit" type="submit">发送</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>


        <!-- Footer -->
        <footer class="footer-area">
            <div class="container">
                <div class="footer-content text-center">
                    <a href="./" class="logo">
                        <img src="<?php echo $logo;?>" alt="" width="156" height="36">
                    </a>
                    <ul class="footer-menu">
                        <li><a href="./index.php">首页</a></li>
                        <li><a href="./about.php">关于</a></li>
                        <li><a href="./sites.php">网站</a></li>
                        <li><a href="./contact.php">联系</a></li>
                    </ul>
                    <?php echo $Copyright; ?>
                </div>
            </div>
        </footer>

    </main>
    

    <script src="assets/js/jquery-3.6.4.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/aos.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/ajax-form.js"></script>
	<script src="./assets/js/icons.js"></script>
    <script type="text/javascript">
//求情
    console.log("%c大侠手下留情,不要搞小站。", "color: #ff146d;font-size: 16px;font-weight: bold")
//申明
    console.log("\n %c 孤独 %c \n", "color: #fadfa3; background: #030307; padding:5px 0; font-size:12px;", "background: #fadfa3; padding:5px 0; font-size:12px;");
   </script>
<!--统计-->
<?php echo $count; ?>
</body>
</html>
