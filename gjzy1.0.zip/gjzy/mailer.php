<?php
include('./admin/WebsiteSettings.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

// 获取表单提交的数据
$name = $_POST['full-name'];
$email = $_POST['email'];
$message = $_POST['message'];

// 设置收件人地址和邮件主题
$to = "";
$subject = '来自'.$name.'的留言';

$mail = new PHPMailer(true);

try {
    // 服务器配置
	$mail->CharSet ="UTF-8"; //设定邮件编码
    $mail->SMTPDebug = 0; // 调试模式输出
    $mail->isSMTP(); // 使用SMTP
    $mail->Host = 'smtp.qq.com'; // SMTP服务器地址
    $mail->SMTPAuth = true; // 启用SMTP认证
    $mail->Username = ''; // SMTP用户名
    $mail->Password = ''; // SMTP密码
    $mail->SMTPSecure = 'ssl'; // 启用TLS加密
    $mail->Port = 465; // 要连接的TCP端口

    // 收件人
  $mail->setFrom('用户名', 'Mailer');//前一个双引号填你的SMTP用户名
  $mail->addAddress($to, '昵称');//昵称改成你想要的

    // 内容
    $mail->isHTML(true); // 将电子邮件格式设置为HTML，修改里面“网址”和“网站名称”
    $mail->Subject = $subject;
    $mail->Body = '<html>'.'<head>'.'<title>'.'</title>'.'</head>'.'<body>'.'<table style="width:99.8%;height:99.8%">'.'<tbody>'.'<tr>'.'<td style="background:#fafafa url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAy0lEQVQY0x2PsQtAYBDFP1keKZfBKIqNycCERUkMKLuSgZnRarIpJX8s3zfcDe9+794du+8bRVHQOI4wDAOmaULTNDDGYFkWMVVVQUTQdZ3iOMZxHCjLElVV0TRNYHVdC7ptW6RpSn3f4wdJkiTs+w6WJAl4DcOAbdugKAq974umaRAEARgXn+cRW3zfFxuiKCJZloXGHMeBbdv4Beq6Duu6Issy7iYB8Jbnucg8zxPLsggnj/zvIxaGIXmeB9d1wSE+nOeZf4HruvABUtou5ypjMF4AAAAASUVORK5CYII=)">'.'<div style="width:100%;background:#49BDAD;color:#fff;border-radius:10px 10px 0 0;background-image:-moz-linear-gradient(0deg,#43c6b8,#ffd1f4);background-image:-webkit-linear-gradient(0deg,#43c6b8,#ffd1f4);height:66px">'.'<p style="font-size:15px;word-break:break-all;padding:23px 32px;margin:0;background-color:hsla(0,0%,100%,.4);border-radius:10px 10px 0 0">'.'您有新的留言！来自'.'<a href="<?php echo $siteurl; ?>"style="text-decoration:none;color:#12addb"target="_blank">'.'<?php echo $title; ?>'.'</a>'.'</p>'.'</div>'.'<div style="margin:40px auto;width:90%">'.'<p>'.$name.'在您的《'.'<a href="网址"style="text-decoration:none;color:#12addb"target="_blank">'.'网站名称'.'</a>'.'》上发表留言：'.'</p>'.'<p style="background:#fafafa repeating-linear-gradient(-45deg,#fff,#fff 1.125rem,transparent 1.125rem,transparent 2.25rem);box-shadow:0 2px 5px rgba(0,0,0,.15);margin:20px 0;padding:15px;border-radius:5px;font-size:14px;color:#555">'.$message.'</p>'.'<p>'.$name.'的邮箱为：'.$email.'</p>'.'</div>'.'</div>'.'</td>'.'</tr>'.'</tbody>'.'</table>'.'</body>'.'</html>'.'<br>';

    $mail->send();
    echo '邮件发送成功';
} catch (Exception $e) {
    echo '邮件发送失败: ', $mail->ErrorInfo;
}
?>